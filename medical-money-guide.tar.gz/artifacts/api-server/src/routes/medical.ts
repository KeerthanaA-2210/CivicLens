import { Router, type IRouter } from "express";
import {
  AnalyzePrescriptionBody,
  AnalyzePrescriptionResponse,
  ListSchemesResponse,
  ListHospitalsResponse,
  GetStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const SCHEMES_DATA = {
  treatments: [
    {
      keywords: ["lap chole", "laparoscopic cholecystectomy", "gallbladder", "cholecystectomy"],
      simple_name: "Gallbladder Surgery",
      estimated_cost: 80000,
      trust_score_range: [58, 72],
      schemes: [
        { name: "PM-JAY (Ayushman Bharat)", coverage_amount: 50000, eligibility: "BPL families and identified beneficiaries", coverage_percentage: 63, recommendation: "Apply if you have PM-JAY card — covers most of the procedure", color: "teal" },
        { name: "Green Card (Karnataka)", coverage_amount: 55000, eligibility: "Karnataka residents with annual income below ₹1.5 lakhs", coverage_percentage: 69, recommendation: "Best option for Karnataka residents — highest coverage", color: "green" },
        { name: "ESI (Employee State Insurance)", coverage_amount: 80000, eligibility: "Employees earning up to ₹21,000/month", coverage_percentage: 100, recommendation: "Full coverage for ESI beneficiaries — check your employer enrollment", color: "blue" },
        { name: "BPL Government Scheme", coverage_amount: 30000, eligibility: "Below Poverty Line card holders", coverage_percentage: 38, recommendation: "Partial coverage — combine with other schemes if possible", color: "orange" },
        { name: "Karnataka Arogya Karnataka", coverage_amount: 60000, eligibility: "Karnataka residents — universal health coverage", coverage_percentage: 75, recommendation: "Universal Karnataka scheme — excellent coverage for state residents", color: "purple" },
      ],
    },
    {
      keywords: ["appendectomy", "appendix", "appendicitis", "appendix removal"],
      simple_name: "Appendix Removal Surgery",
      estimated_cost: 55000,
      trust_score_range: [60, 75],
      schemes: [
        { name: "PM-JAY (Ayushman Bharat)", coverage_amount: 45000, eligibility: "BPL families and identified beneficiaries", coverage_percentage: 82, recommendation: "Excellent coverage under PM-JAY for this procedure", color: "teal" },
        { name: "Green Card (Karnataka)", coverage_amount: 50000, eligibility: "Karnataka residents with annual income below ₹1.5 lakhs", coverage_percentage: 91, recommendation: "Near-complete coverage — highly recommended", color: "green" },
        { name: "ESI (Employee State Insurance)", coverage_amount: 55000, eligibility: "Employees earning up to ₹21,000/month", coverage_percentage: 100, recommendation: "Full coverage for ESI members", color: "blue" },
        { name: "BPL Government Scheme", coverage_amount: 25000, eligibility: "Below Poverty Line card holders", coverage_percentage: 45, recommendation: "Partial support — explore PM-JAY for better coverage", color: "orange" },
        { name: "Karnataka Arogya Karnataka", coverage_amount: 48000, eligibility: "Karnataka residents — universal health coverage", coverage_percentage: 87, recommendation: "Strong Karnataka state coverage for this procedure", color: "purple" },
      ],
    },
    {
      keywords: ["kidney stone", "nephrolithiasis", "ureteroscopy", "pcnl", "lithotripsy", "kidney"],
      simple_name: "Kidney Stone Treatment",
      estimated_cost: 65000,
      trust_score_range: [55, 70],
      schemes: [
        { name: "PM-JAY (Ayushman Bharat)", coverage_amount: 40000, eligibility: "BPL families and identified beneficiaries", coverage_percentage: 62, recommendation: "Good coverage — request itemized bill to verify", color: "teal" },
        { name: "Green Card (Karnataka)", coverage_amount: 50000, eligibility: "Karnataka residents with annual income below ₹1.5 lakhs", coverage_percentage: 77, recommendation: "Best state scheme for kidney stone procedures", color: "green" },
        { name: "ESI (Employee State Insurance)", coverage_amount: 65000, eligibility: "Employees earning up to ₹21,000/month", coverage_percentage: 100, recommendation: "Complete coverage under ESI", color: "blue" },
        { name: "BPL Government Scheme", coverage_amount: 20000, eligibility: "Below Poverty Line card holders", coverage_percentage: 31, recommendation: "Limited support — pursue Green Card or PM-JAY", color: "orange" },
        { name: "Karnataka Arogya Karnataka", coverage_amount: 55000, eligibility: "Karnataka residents — universal health coverage", coverage_percentage: 85, recommendation: "Excellent Karnataka state coverage", color: "purple" },
      ],
    },
    {
      keywords: ["cataract", "phacoemulsification", "eye surgery", "iol", "lens replacement", "eye"],
      simple_name: "Cataract Eye Surgery",
      estimated_cost: 40000,
      trust_score_range: [65, 80],
      schemes: [
        { name: "PM-JAY (Ayushman Bharat)", coverage_amount: 35000, eligibility: "BPL families and identified beneficiaries", coverage_percentage: 88, recommendation: "Near-complete coverage — highly recommended", color: "teal" },
        { name: "Green Card (Karnataka)", coverage_amount: 38000, eligibility: "Karnataka residents with annual income below ₹1.5 lakhs", coverage_percentage: 95, recommendation: "Excellent coverage — best option for Karnataka residents", color: "green" },
        { name: "ESI (Employee State Insurance)", coverage_amount: 40000, eligibility: "Employees earning up to ₹21,000/month", coverage_percentage: 100, recommendation: "Full coverage under ESI", color: "blue" },
        { name: "BPL Government Scheme", coverage_amount: 20000, eligibility: "Below Poverty Line card holders", coverage_percentage: 50, recommendation: "Partial coverage — combine with state schemes", color: "orange" },
        { name: "Karnataka Arogya Karnataka", coverage_amount: 38000, eligibility: "Karnataka residents — universal health coverage", coverage_percentage: 95, recommendation: "Excellent state scheme for eye surgeries", color: "purple" },
      ],
    },
    {
      keywords: ["hernia", "hernia repair", "herniorrhaphy", "inguinal hernia", "laparoscopic hernia"],
      simple_name: "Hernia Repair Surgery",
      estimated_cost: 60000,
      trust_score_range: [60, 75],
      schemes: [
        { name: "PM-JAY (Ayushman Bharat)", coverage_amount: 45000, eligibility: "BPL families and identified beneficiaries", coverage_percentage: 75, recommendation: "Good coverage — verify hospital is PM-JAY empanelled", color: "teal" },
        { name: "Green Card (Karnataka)", coverage_amount: 50000, eligibility: "Karnataka residents with annual income below ₹1.5 lakhs", coverage_percentage: 83, recommendation: "Strong coverage for Karnataka residents", color: "green" },
        { name: "ESI (Employee State Insurance)", coverage_amount: 60000, eligibility: "Employees earning up to ₹21,000/month", coverage_percentage: 100, recommendation: "Complete coverage for ESI members", color: "blue" },
        { name: "BPL Government Scheme", coverage_amount: 25000, eligibility: "Below Poverty Line card holders", coverage_percentage: 42, recommendation: "Limited — explore PM-JAY and Green Card for better coverage", color: "orange" },
        { name: "Karnataka Arogya Karnataka", coverage_amount: 52000, eligibility: "Karnataka residents — universal health coverage", coverage_percentage: 87, recommendation: "Recommended for Karnataka residents", color: "purple" },
      ],
    },
  ],
  default: {
    simple_name: "Medical Procedure",
    estimated_cost: 70000,
    trust_score_range: [60, 75],
    schemes: [
      { name: "PM-JAY (Ayushman Bharat)", coverage_amount: 40000, eligibility: "BPL families and identified beneficiaries", coverage_percentage: 57, recommendation: "Check if procedure is covered under PM-JAY package list", color: "teal" },
      { name: "Green Card (Karnataka)", coverage_amount: 45000, eligibility: "Karnataka residents with annual income below ₹1.5 lakhs", coverage_percentage: 64, recommendation: "Good option for Karnataka residents", color: "green" },
      { name: "ESI (Employee State Insurance)", coverage_amount: 70000, eligibility: "Employees earning up to ₹21,000/month", coverage_percentage: 100, recommendation: "Full coverage if you are an ESI beneficiary", color: "blue" },
      { name: "BPL Government Scheme", coverage_amount: 20000, eligibility: "Below Poverty Line card holders", coverage_percentage: 29, recommendation: "Partial support available", color: "orange" },
      { name: "Karnataka Arogya Karnataka", coverage_amount: 50000, eligibility: "Karnataka residents — universal health coverage", coverage_percentage: 71, recommendation: "Strong state-level coverage available", color: "purple" },
    ],
  },
  hospitals: [
    { name: "Rajiv Gandhi Government Hospital", trust_score: 89, affordability: "Very Affordable", scheme_support: ["PM-JAY", "Green Card", "BPL", "ESI"], distance: "2.3 km", risk_level: "Low" },
    { name: "Victoria Hospital (Bangalore)", trust_score: 84, affordability: "Affordable", scheme_support: ["PM-JAY", "Green Card", "ESI"], distance: "4.1 km", risk_level: "Low" },
    { name: "Indira Gandhi Institute of Child Health", trust_score: 78, affordability: "Affordable", scheme_support: ["PM-JAY", "Green Card"], distance: "5.8 km", risk_level: "Low" },
    { name: "Bowring & Lady Curzon Hospital", trust_score: 76, affordability: "Affordable", scheme_support: ["PM-JAY", "ESI", "BPL"], distance: "3.6 km", risk_level: "Low" },
    { name: "KC General Hospital", trust_score: 71, affordability: "Moderate", scheme_support: ["PM-JAY", "Green Card"], distance: "6.2 km", risk_level: "Medium" },
  ],
  stats: { families_helped: 48291, savings_total: 284000000, schemes_matched: 127450, overcharges_detected: 9823 },
};

type Treatment = (typeof SCHEMES_DATA.treatments)[0];

function findTreatment(text: string): Treatment | null {
  const lowerText = text.toLowerCase();
  for (const treatment of SCHEMES_DATA.treatments) {
    for (const keyword of treatment.keywords) {
      if (lowerText.includes(keyword.toLowerCase())) {
        return treatment;
      }
    }
  }
  return null;
}

function randomInRange(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pickBestScheme(schemes: Array<{ name: string; coverage_amount: number }>): string {
  return schemes.reduce((best, s) => (s.coverage_amount > best.coverage_amount ? s : best)).name;
}

router.post("/analyze", (req, res) => {
  const parsed = AnalyzePrescriptionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body", details: parsed.error.issues });
    return;
  }

  const { text } = parsed.data;
  const treatment = findTreatment(text);
  const data = treatment ?? SCHEMES_DATA.default;

  const estimatedCost = data.estimated_cost;
  const trustScore = randomInRange(data.trust_score_range[0], data.trust_score_range[1]);
  const bestSchemeName = pickBestScheme(data.schemes);
  const bestScheme = data.schemes.find((s) => s.name === bestSchemeName);
  const governmentCoverage = bestScheme?.coverage_amount ?? 40000;
  const possibleOvercharge = Math.floor(estimatedCost * 0.25);
  const patientExpense = Math.max(0, estimatedCost - governmentCoverage);
  const savingsPercentage = Math.round((governmentCoverage / estimatedCost) * 100);
  const riskLevel = trustScore >= 75 ? "Low" : trustScore >= 60 ? "Medium" : "High";

  const originalTermMap: Record<string, string> = {
    "Gallbladder Surgery": "Lap Chole (Laparoscopic Cholecystectomy)",
    "Appendix Removal Surgery": "Appendectomy",
    "Kidney Stone Treatment": "Nephrolithiasis / PCNL",
    "Cataract Eye Surgery": "Phacoemulsification + IOL",
    "Hernia Repair Surgery": "Laparoscopic Herniorrhaphy",
    "Medical Procedure": text.substring(0, 60),
  };

  const originalTerm = originalTermMap[data.simple_name] ?? text.substring(0, 60);

  const questionMap: Record<string, string[]> = {
    "Gallbladder Surgery": [
      "Is this surgery covered under PM-JAY or Green Card scheme?",
      "Can I get an itemized bill with procedure codes?",
      "Is laparoscopic approach medically necessary?",
      "Are there government hospitals performing this at lower cost?",
      "Is immediate surgery required or can it be planned?",
    ],
    "Appendix Removal Surgery": [
      "Is this an emergency appendectomy or can it be scheduled?",
      "Is the hospital empanelled under PM-JAY?",
      "Can I see an itemized cost breakdown before admission?",
      "Are there affordable alternatives at government hospitals?",
      "What is the total expected stay and post-op costs?",
    ],
    "Kidney Stone Treatment": [
      "Is this covered under PM-JAY or Green Card?",
      "Which procedure — PCNL, URS, or lithotripsy — is recommended?",
      "Can I get an itemized bill before treatment?",
      "Are government hospitals offering this at lower cost?",
      "Is immediate treatment necessary?",
    ],
    "Cataract Eye Surgery": [
      "Is this covered under PM-JAY or Green Card scheme?",
      "Is phacoemulsification or ECCE being recommended?",
      "What IOL (lens) type is included in the scheme coverage?",
      "Are there government eye hospitals offering free surgery?",
      "Can this surgery be scheduled for a later date safely?",
    ],
    "Hernia Repair Surgery": [
      "Is this covered under PM-JAY or Green Card?",
      "Is open or laparoscopic repair being recommended?",
      "Can I get an itemized cost breakdown?",
      "Are government hospitals offering this procedure?",
      "Is immediate surgery required?",
    ],
    default: [
      "Is this procedure covered under PM-JAY or Green Card?",
      "Can I get an itemized bill?",
      "Are cheaper alternatives available at government hospitals?",
      "Is immediate treatment necessary?",
      "What is the complete cost including post-operative care?",
    ],
  };

  const questions = questionMap[data.simple_name] ?? questionMap.default;

  const result = AnalyzePrescriptionResponse.parse({
    simple_name: data.simple_name,
    original_term: originalTerm,
    confidence_score: randomInRange(82, 96),
    financial: {
      estimated_hospital_cost: estimatedCost,
      government_coverage: governmentCoverage,
      patient_expense: patientExpense,
      possible_overcharge: possibleOvercharge,
      savings_percentage: savingsPercentage,
    },
    best_scheme: bestSchemeName,
    schemes: data.schemes,
    trust_score: trustScore,
    risk_level: riskLevel,
    nearby_hospitals: SCHEMES_DATA.hospitals,
    questions_to_ask: questions,
    next_steps: [
      `Visit nearest PM-JAY empanelled hospital to verify ${data.simple_name} coverage`,
      "Carry Aadhaar card and ration card for scheme eligibility check",
      "Request itemized bill before any surgery or procedure",
      `Apply for ${bestSchemeName} if not already enrolled`,
      "Contact 1800-111-565 (PM-JAY helpline) for scheme guidance",
      "Compare costs at 2-3 government hospitals before deciding",
    ],
  });

  res.json(result);
});

router.get("/schemes", (_req, res) => {
  const result = ListSchemesResponse.parse(SCHEMES_DATA.default.schemes);
  res.json(result);
});

router.get("/hospitals", (_req, res) => {
  const result = ListHospitalsResponse.parse(SCHEMES_DATA.hospitals);
  res.json(result);
});

router.get("/stats", (_req, res) => {
  const result = GetStatsResponse.parse(SCHEMES_DATA.stats);
  res.json(result);
});

export default router;
