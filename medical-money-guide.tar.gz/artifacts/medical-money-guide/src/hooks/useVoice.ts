import { useState, useCallback, useRef, useEffect } from "react";
import type { AnalysisResult } from "@workspace/api-client-react";

export type VoiceLang = "en" | "kn" | "hi";

export interface VoiceState {
  isSpeaking: boolean;
  isListening: boolean;
  isSupported: boolean;
  isSttSupported: boolean;
  currentLang: VoiceLang;
  transcript: string;
}

// Minimal browser Speech Recognition type declarations
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  length: number;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionInstance extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}

interface SpeechRecognitionConstructor {
  new (): SpeechRecognitionInstance;
}

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

function formatINR(n: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);
}

function buildScript(result: AnalysisResult, lang: VoiceLang): string {
  const { simple_name, confidence_score, financial, best_scheme, trust_score, risk_level } = result;
  const cov = formatINR(financial.government_coverage);
  const cost = formatINR(financial.estimated_hospital_cost);
  const exp = formatINR(financial.patient_expense);
  const over = formatINR(financial.possible_overcharge);

  if (lang === "hi") {
    return (
      `नमस्ते! मैं मेडिकल मनी गाइड हूं। ` +
      `आपके पर्चे का विश्लेषण पूरा हो गया है। ` +
      `प्रक्रिया है: ${simple_name}। ` +
      `मेरी सटीकता ${confidence_score} प्रतिशत है। ` +
      `अस्पताल की अनुमानित लागत ${cost} है। ` +
      `सरकारी योजना ${best_scheme} के तहत ${cov} की कवरेज मिलेगी। ` +
      `आपका अनुमानित खर्च ${exp} होगा। ` +
      `संभावित अधिक शुल्क ${over} है — कृपया सावधान रहें। ` +
      `अस्पताल का विश्वास स्कोर ${trust_score} प्रतिशत है, जो ${risk_level} जोखिम दर्शाता है। ` +
      `अधिक जानकारी के लिए पीएम जय हेल्पलाइन 1800-111-565 पर कॉल करें।`
    );
  }

  if (lang === "kn") {
    return (
      `ನಮಸ್ಕಾರ! ನಾನು ಮೆಡಿಕಲ್ ಮನಿ ಗೈಡ್. ` +
      `ನಿಮ್ಮ ಪ್ರಿಸ್ಕ್ರಿಪ್ಷನ್ ವಿಶ್ಲೇಷಣೆ ಮುಗಿದಿದೆ. ` +
      `ಚಿಕಿತ್ಸೆ: ${simple_name}. ` +
      `ನನ್ನ ನಿಖರತೆ ${confidence_score} ಶೇಕಡಾ. ` +
      `ಆಸ್ಪತ್ರೆ ವೆಚ್ಚ ಅಂದಾಜು ${cost}. ` +
      `ಸರ್ಕಾರಿ ಯೋಜನೆ ${best_scheme} ಅಡಿಯಲ್ಲಿ ${cov} ಕವರೇಜ್ ಲಭ್ಯ. ` +
      `ನಿಮ್ಮ ಅಂದಾಜು ಖರ್ಚು ${exp}. ` +
      `ಸಂಭಾವ್ಯ ಅತಿ ಶುಲ್ಕ ${over} — ದಯವಿಟ್ಟು ಎಚ್ಚರಿಕೆಯಿಂದಿರಿ. ` +
      `ಆಸ್ಪತ್ರೆ ವಿಶ್ವಾಸ ಅಂಕ ${trust_score} ಶೇಕಡಾ, ${risk_level} ಅಪಾಯ. ` +
      `ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಪಿಎಂ ಜೈ ಹೆಲ್ಪ್ ಲೈನ್ 1800-111-565 ಗೆ ಕರೆ ಮಾಡಿ.`
    );
  }

  return (
    `Hello! I am your Medical Money Guide assistant. ` +
    `Your prescription analysis is complete. ` +
    `The identified procedure is ${simple_name}, with ${confidence_score} percent confidence. ` +
    `The estimated hospital cost is ${cost}. ` +
    `Under the ${best_scheme} scheme, you can receive ${cov} in government coverage. ` +
    `Your estimated out-of-pocket expense will be ${exp}. ` +
    `A possible overcharge of ${over} has been detected — please request an itemized bill. ` +
    `The hospital trust score is ${trust_score} percent, indicating ${risk_level} risk. ` +
    `For assistance, call the PM-JAY helpline at 1800-111-565.`
  );
}

const LANG_CODES: Record<VoiceLang, string> = {
  en: "en-IN",
  kn: "kn-IN",
  hi: "hi-IN",
};

function getSpeechRecognition(): SpeechRecognitionConstructor | undefined {
  if (typeof window === "undefined") return undefined;
  return window.SpeechRecognition ?? window.webkitSpeechRecognition;
}

export function useVoice() {
  const [state, setState] = useState<VoiceState>({
    isSpeaking: false,
    isListening: false,
    isSupported: typeof window !== "undefined" && "speechSynthesis" in window,
    isSttSupported: typeof window !== "undefined" && !!(window.SpeechRecognition ?? window.webkitSpeechRecognition),
    currentLang: "en",
    transcript: "",
  });

  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);

  useEffect(() => {
    return () => {
      window.speechSynthesis?.cancel();
      recognitionRef.current?.stop();
    };
  }, []);

  const setLang = useCallback((lang: VoiceLang) => {
    setState((s) => ({ ...s, currentLang: lang }));
  }, []);

  const speak = useCallback(
    (text: string, lang?: VoiceLang) => {
      if (!("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      const targetLang = lang ?? state.currentLang;
      utterance.lang = LANG_CODES[targetLang];
      utterance.rate = 0.92;
      utterance.pitch = 1.05;
      utterance.volume = 1;

      const voices = window.speechSynthesis.getVoices();
      const langPrefix = LANG_CODES[targetLang].split("-")[0];
      const preferred =
        voices.find((v) => v.lang.startsWith(langPrefix) && v.localService) ??
        voices.find((v) => v.lang.startsWith(langPrefix));
      if (preferred) utterance.voice = preferred;

      utterance.onstart = () => setState((s) => ({ ...s, isSpeaking: true }));
      utterance.onend = () => setState((s) => ({ ...s, isSpeaking: false }));
      utterance.onerror = () => setState((s) => ({ ...s, isSpeaking: false }));

      window.speechSynthesis.speak(utterance);
    },
    [state.currentLang]
  );

  const speakResult = useCallback(
    (result: AnalysisResult, lang?: VoiceLang) => {
      const l = lang ?? state.currentLang;
      speak(buildScript(result, l), l);
    },
    [speak, state.currentLang]
  );

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis?.cancel();
    setState((s) => ({ ...s, isSpeaking: false }));
  }, []);

  const startListening = useCallback(
    (onResult: (transcript: string) => void, lang?: VoiceLang) => {
      const RecognitionClass = getSpeechRecognition();
      if (!RecognitionClass) return;

      const recognition = new RecognitionClass();
      recognitionRef.current = recognition;
      const targetLang = lang ?? state.currentLang;
      recognition.lang = LANG_CODES[targetLang];
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      recognition.onstart = () =>
        setState((s) => ({ ...s, isListening: true, transcript: "" }));

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        const resultList = event.results;
        let t = "";
        for (let i = 0; i < resultList.length; i++) {
          t += resultList[i][0].transcript;
        }
        setState((s) => ({ ...s, transcript: t }));
        if (resultList[resultList.length - 1].isFinal) {
          onResult(t);
        }
      };

      recognition.onerror = () =>
        setState((s) => ({ ...s, isListening: false }));

      recognition.onend = () =>
        setState((s) => ({ ...s, isListening: false }));

      recognition.start();
    },
    [state.currentLang]
  );

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setState((s) => ({ ...s, isListening: false }));
  }, []);

  return {
    ...state,
    setLang,
    speak,
    speakResult,
    stopSpeaking,
    startListening,
    stopListening,
  };
}
