import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { gsap } from "gsap";
import { useAnalyzePrescription, useGetStats } from "@workspace/api-client-react";
import type { AnalysisResult } from "@workspace/api-client-react";
import { Activity, Scan, Shield, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

import { ScanModal } from "@/components/ScanModal";
import { FinancialDashboard } from "@/components/FinancialDashboard";
import { VoiceAssistant } from "@/components/VoiceAssistant";
import { useVoice } from "@/hooks/useVoice";
import type { VoiceLang } from "@/hooks/useVoice";

export default function Home() {
  const [isScanModalOpen, setIsScanModalOpen] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  const analyzeMutation = useAnalyzePrescription();
  const { data: stats } = useGetStats();

  const voice = useVoice();

  useEffect(() => {
    if (heroRef.current) {
      gsap.fromTo(
        heroRef.current.querySelectorAll('.animate-up'),
        { y: 50, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, stagger: 0.2, ease: "power3.out" }
      );
    }
  }, []);

  const handleScanComplete = async (text: string) => {
    setIsAnalyzing(true);
    setIsScanModalOpen(false);
    voice.stopSpeaking();
    try {
      const result = await analyzeMutation.mutateAsync({ data: { text } });
      setAnalysisResult(result);
      setTimeout(() => {
        document.getElementById('results-section')?.scrollIntoView({ behavior: 'smooth' });
        // Auto-read results after scrolling
        setTimeout(() => {
          voice.speakResult(result);
        }, 1200);
      }, 500);
    } catch (error) {
      console.error("Failed to analyze:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleVoiceListen = () => {
    voice.startListening((transcript) => {
      // transcript is final — ScanModal effect handles it
    });
  };

  const handleLangChange = (lang: VoiceLang) => {
    voice.setLang(lang);
    if (voice.isSpeaking) voice.stopSpeaking();
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden selection:bg-primary/30">
      {/* Background Particles */}
      <div className="particles-bg">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              width: `${Math.random() * 100 + 50}px`,
              height: `${Math.random() * 100 + 50}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100 + 100}%`,
              animationDelay: `${Math.random() * 20}s`,
              animationDuration: `${Math.random() * 15 + 15}s`
            }}
          />
        ))}
      </div>

      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 glass-card border-b border-white/5 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-8 h-8 text-primary" />
            <span className="font-heading font-bold text-xl tracking-tight text-white">
              Medical Money <span className="text-primary">Guide</span>
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-2 bg-secondary/50 rounded-full px-3 py-1.5 border border-white/10">
              <Languages className="w-4 h-4 text-muted-foreground" />
              {(["en", "kn", "hi"] as VoiceLang[]).map((lang, i, arr) => (
                <React.Fragment key={lang}>
                  <button
                    onClick={() => handleLangChange(lang)}
                    className="text-xs font-medium transition-colors"
                    style={{ color: voice.currentLang === lang ? "hsl(180 70% 45%)" : "rgba(255,255,255,0.45)" }}
                  >
                    {lang === "en" ? "EN" : lang === "kn" ? "ಕನ್ನಡ" : "हिंदी"}
                  </button>
                  {i < arr.length - 1 && <span className="text-white/20">|</span>}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center pt-20 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center z-10">
          <div className="animate-up inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card border-primary/30 text-primary mb-8">
            <Shield className="w-4 h-4" />
            <span className="text-sm font-medium">Understanding Treatment. Protecting Families.</span>
          </div>

          <h1 className="animate-up font-heading text-5xl md:text-7xl font-bold leading-tight mb-6">
            What if a medical emergency could destroy a{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400 glow-text-teal">
              family's savings?
            </span>
          </h1>

          <p className="animate-up text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto font-sans font-light">
            Millions of Indian families struggle to understand healthcare costs, verify standard pricing, and access government schemes.
          </p>

          <div className="animate-up flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              size="lg"
              className="glow-teal bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 py-6 text-lg font-medium group relative overflow-hidden"
              onClick={() => setIsScanModalOpen(true)}
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
              <Scan className="w-5 h-5 mr-2 relative z-10" />
              <span className="relative z-10">Scan Prescription</span>
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="rounded-full px-8 py-6 text-lg glass-card border-white/10 hover:bg-white/5"
              onClick={() => {
                voice.speak(
                  "Welcome to Medical Money Guide. We help Indian families understand healthcare costs and access government schemes. Click Scan Prescription to get started.",
                  voice.currentLang
                );
              }}
            >
              Watch Demo
            </Button>
          </div>
        </div>

        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[120px] pointer-events-none -z-10" />
      </section>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isAnalyzing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background/90 backdrop-blur-md flex flex-col items-center justify-center"
          >
            <div className="relative w-32 h-32 mb-8">
              <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
              <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Activity className="w-10 h-10 text-primary animate-pulse" />
              </div>
            </div>
            <motion.h3
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="text-2xl font-heading font-bold text-white mb-2"
            >
              AI is processing...
            </motion.h3>
            <div className="flex flex-col items-center gap-2 text-muted-foreground font-mono text-sm">
              <span className="text-primary">Extracting medical terms...</span>
              <span>Cross-referencing hospital rates...</span>
              <span>Matching government schemes...</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results Section */}
      <AnimatePresence>
        {analysisResult && !isAnalyzing && (
          <motion.section
            id="results-section"
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="py-20 px-6 max-w-7xl mx-auto relative z-10"
          >
            <FinancialDashboard result={analysisResult} currentLang={voice.currentLang} />
          </motion.section>
        )}
      </AnimatePresence>

      {/* Stats Section */}
      <section className="py-24 border-t border-white/5 relative z-10 bg-black/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-heading font-bold mb-4">Healthcare transparency saves lives.</h2>
            <p className="text-muted-foreground">The impact we've made so far.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="glass-card border-none bg-white/5">
              <CardContent className="p-8 text-center">
                <h4 className="text-4xl font-heading font-bold text-white mb-2">
                  {stats?.families_helped ? stats.families_helped.toLocaleString() : "12,450"}
                </h4>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Families Helped</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-none bg-white/5">
              <CardContent className="p-8 text-center">
                <h4 className="text-4xl font-heading font-bold text-primary mb-2">
                  ₹{stats?.savings_total ? (stats.savings_total / 10000000).toFixed(1) : "8.5"}Cr
                </h4>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Total Savings</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-none bg-white/5">
              <CardContent className="p-8 text-center">
                <h4 className="text-4xl font-heading font-bold text-white mb-2">
                  {stats?.schemes_matched ? stats.schemes_matched.toLocaleString() : "8,920"}
                </h4>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Schemes Matched</p>
              </CardContent>
            </Card>
            <Card className="glass-card border-none bg-white/5">
              <CardContent className="p-8 text-center">
                <h4 className="text-4xl font-heading font-bold text-destructive mb-2">
                  {stats?.overcharges_detected ? stats.overcharges_detected.toLocaleString() : "4,130"}
                </h4>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Overcharges Blocked</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Scan Modal with voice input */}
      <ScanModal
        isOpen={isScanModalOpen}
        onClose={() => {
          setIsScanModalOpen(false);
          if (voice.isListening) voice.stopListening();
        }}
        onScanComplete={handleScanComplete}
        onStartVoiceInput={voice.isSttSupported ? handleVoiceListen : undefined}
        onStopVoiceInput={voice.isSttSupported ? voice.stopListening : undefined}
        isListening={voice.isListening}
        voiceTranscript={voice.transcript}
      />

      {/* Floating Voice Assistant Widget */}
      <VoiceAssistant
        isSpeaking={voice.isSpeaking}
        isListening={voice.isListening}
        isSupported={voice.isSupported}
        isSttSupported={voice.isSttSupported}
        currentLang={voice.currentLang}
        hasResult={!!analysisResult}
        onSpeak={() => analysisResult && voice.speakResult(analysisResult)}
        onStop={voice.stopSpeaking}
        onListen={() => {
          setIsScanModalOpen(true);
          setTimeout(() => handleVoiceListen(), 300);
        }}
        onStopListening={voice.stopListening}
        onLangChange={handleLangChange}
      />
    </div>
  );
}
