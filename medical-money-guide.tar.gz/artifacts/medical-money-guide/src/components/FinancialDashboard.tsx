import { useState } from "react";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  CheckCircle2,
  MapPin,
  ChevronRight,
  Shield,
  Brain,
  IndianRupee,
  Hospital,
  MessageSquare,
  Volume2,
  Rocket,
  TrendingDown,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { RadialBarChart, RadialBar, ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";
import type { AnalysisResult } from "@workspace/api-client-react";

interface FinancialDashboardProps {
  result: AnalysisResult;
  currentLang?: "en" | "kn" | "hi";
}

function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

const SCHEME_COLORS: Record<string, string> = {
  teal: "hsl(180 70% 45%)",
  green: "hsl(142 71% 45%)",
  blue: "hsl(214 90% 60%)",
  orange: "hsl(30 90% 55%)",
  purple: "hsl(280 65% 60%)",
};

const RISK_CONFIG: Record<string, { color: string; bg: string; label: string }> = {
  Low: { color: "hsl(142 71% 45%)", bg: "rgba(56, 200, 90, 0.1)", label: "LOW RISK" },
  Medium: { color: "hsl(45 90% 55%)", bg: "rgba(234, 179, 8, 0.1)", label: "MEDIUM RISK" },
  High: { color: "hsl(0 84% 60%)", bg: "rgba(220, 60, 60, 0.1)", label: "HIGH RISK" },
};

const FUTURE_FEATURES = [
  { icon: Brain, label: "Real OCR APIs", desc: "Tesseract + Google Vision integration" },
  { icon: Volume2, label: "AI Voice Assistant", desc: "Multilingual health guidance" },
  { icon: Shield, label: "Insurance Integration", desc: "Auto-claim filing support" },
  { icon: MessageSquare, label: "WhatsApp Assistant", desc: "Scheme updates via WhatsApp" },
  { icon: AlertTriangle, label: "Fraud Detection", desc: "Real-time billing anomaly alerts" },
  { icon: Rocket, label: "Real-time Eligibility", desc: "Live government scheme matching" },
];

const SECTION_VARIANTS = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
} as const;

export function FinancialDashboard({ result }: FinancialDashboardProps) {
  const [language, setLanguage] = useState<"en" | "kn" | "hi">("en");
  const { financial, schemes, trust_score, risk_level } = result;
  const riskConfig = RISK_CONFIG[risk_level] ?? RISK_CONFIG.Medium;

  const pieData = [
    { name: "Government Coverage", value: financial.government_coverage, color: "hsl(142 71% 45%)" },
    { name: "Patient Expense", value: financial.patient_expense, color: "hsl(180 70% 45%)" },
  ];

  const overchargePercent = Math.min(
    100,
    Math.round((financial.possible_overcharge / financial.estimated_hospital_cost) * 100)
  );

  const trustData = [{ value: trust_score, fill: riskConfig.color }];

  const translatedTitle: Record<string, string> = {
    en: "Your Healthcare Financial Protection Report",
    kn: "ನಿಮ್ಮ ಆರೋಗ್ಯ ಹಣಕಾಸು ಸಂರಕ್ಷಣಾ ವರದಿ",
    hi: "आपकी स्वास्थ्य वित्तीय सुरक्षा रिपोर्ट",
  };

  const card = (children: React.ReactNode, className = "") => (
    <div
      className={`rounded-2xl p-6 ${className}`}
      style={{
        background: "rgba(14, 20, 38, 0.8)",
        border: "1px solid rgba(255,255,255,0.07)",
        backdropFilter: "blur(16px)",
      }}
    >
      {children}
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Report Header */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" className="text-center">
        <div
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-medium"
          style={{
            background: "rgba(56, 211, 183, 0.1)",
            border: "1px solid rgba(56, 211, 183, 0.25)",
            color: "hsl(180 70% 45%)",
          }}
        >
          <CheckCircle2 className="w-4 h-4" />
          Analysis Complete
        </div>
        <h2 className="text-3xl font-bold text-white mb-2">{translatedTitle[language]}</h2>
        <p className="text-white/40 text-sm">Based on your prescription · Powered by Medical Money Guide AI</p>
      </motion.div>

      {/* Section 3: AI Medical Mapper */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
        {card(
          <div className="flex flex-col md:flex-row md:items-center gap-6">
            <div className="flex-1">
              <p className="text-xs uppercase tracking-wider text-white/30 mb-3 flex items-center gap-2">
                <Brain className="w-3.5 h-3.5" /> AI Medical Mapper
              </p>
              <div className="flex items-center gap-4">
                <div
                  className="px-4 py-2 rounded-xl text-sm font-mono"
                  style={{ background: "rgba(255,255,255,0.05)", color: "hsl(180 70% 45%)" }}
                >
                  {result.original_term}
                </div>
                <ChevronRight className="w-5 h-5 text-white/30" />
                <div
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-white"
                  style={{ background: "rgba(56, 211, 183, 0.1)", border: "1px solid rgba(56,211,183,0.25)" }}
                >
                  {result.simple_name}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs text-white/30 mb-1">AI Confidence</p>
                <p className="text-3xl font-bold" style={{ color: "hsl(142 71% 45%)" }}>
                  {result.confidence_score}%
                </p>
              </div>
              <div className="w-px h-12 bg-white/10" />
              <div className="text-right">
                <p className="text-xs text-white/30 mb-1">Best Scheme</p>
                <p className="text-sm font-semibold text-white">{result.best_scheme}</p>
              </div>
            </div>
          </div>
        )}
      </motion.div>

      {/* Section 5: Financial Analysis */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.2 }}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Financial Cards */}
          <div className="lg:col-span-2 grid grid-cols-2 gap-4">
            {[
              {
                label: "Estimated Hospital Cost",
                value: formatINR(financial.estimated_hospital_cost),
                color: "text-white",
                bg: "rgba(255,255,255,0.03)",
                border: "rgba(255,255,255,0.07)",
                icon: IndianRupee,
              },
              {
                label: "Government Coverage",
                value: formatINR(financial.government_coverage),
                color: "text-green-400",
                bg: "rgba(56, 200, 90, 0.06)",
                border: "rgba(56, 200, 90, 0.2)",
                icon: Shield,
                glow: true,
              },
              {
                label: "Your Estimated Expense",
                value: formatINR(financial.patient_expense),
                color: "hsl(180 70% 45%)",
                bg: "rgba(56, 211, 183, 0.05)",
                border: "rgba(56, 211, 183, 0.2)",
                icon: IndianRupee,
              },
              {
                label: "Possible Overcharge",
                value: formatINR(financial.possible_overcharge),
                color: "text-red-400",
                bg: "rgba(220, 60, 60, 0.06)",
                border: "rgba(220, 60, 60, 0.2)",
                icon: AlertTriangle,
                warning: true,
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 + i * 0.08 }}
                className="rounded-2xl p-5"
                style={{
                  background: item.bg,
                  border: `1px solid ${item.border}`,
                  boxShadow: item.warning ? "0 0 20px rgba(220,60,60,0.08)" : item.glow ? "0 0 20px rgba(56,200,90,0.08)" : "none",
                }}
              >
                <div className="flex items-center justify-between mb-3">
                  <item.icon
                    className="w-4 h-4"
                    style={{ color: item.warning ? "hsl(0 84% 60%)" : item.glow ? "hsl(142 71% 45%)" : "hsl(180 70% 45%)" }}
                  />
                  {item.warning && (
                    <span
                      className="text-xs font-bold px-2 py-0.5 rounded-full"
                      style={{ background: "rgba(220,60,60,0.15)", color: "hsl(0 84% 60%)" }}
                    >
                      ALERT
                    </span>
                  )}
                  {item.glow && (
                    <span
                      className="text-xs font-bold px-2 py-0.5 rounded-full"
                      style={{ background: "rgba(56,200,90,0.15)", color: "hsl(142 71% 45%)" }}
                    >
                      COVERED
                    </span>
                  )}
                </div>
                <p className={`text-2xl font-bold mb-1 ${item.color}`}>{item.value}</p>
                <p className="text-xs text-white/40">{item.label}</p>
              </motion.div>
            ))}
          </div>

          {/* Pie Chart */}
          <div
            className="rounded-2xl p-5 flex flex-col"
            style={{ background: "rgba(14,20,38,0.8)", border: "1px solid rgba(255,255,255,0.07)" }}
          >
            <p className="text-xs uppercase tracking-wider text-white/30 mb-4 flex items-center gap-2">
              <TrendingDown className="w-3.5 h-3.5" /> Cost Breakdown
            </p>
            <div className="flex-1 min-h-[140px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [formatINR(value), ""]}
                    contentStyle={{
                      background: "rgba(14,20,38,0.95)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: "0.5rem",
                      color: "#fff",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 mt-2">
              {pieData.map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: item.color }} />
                  <span className="text-xs text-white/60 flex-1">{item.name}</span>
                  <span className="text-xs font-medium text-white">{formatINR(item.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Savings Bar */}
        <div
          className="mt-4 rounded-2xl p-5"
          style={{ background: "rgba(56,200,90,0.05)", border: "1px solid rgba(56,200,90,0.15)" }}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-white">Government Coverage Savings</span>
            <span className="text-lg font-bold" style={{ color: "hsl(142 71% 45%)" }}>
              {financial.savings_percentage}%
            </span>
          </div>
          <div className="relative h-3 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${financial.savings_percentage}%` }}
              transition={{ duration: 1.5, ease: "easeOut", delay: 0.5 }}
              className="absolute left-0 top-0 h-full rounded-full"
              style={{ background: "linear-gradient(90deg, hsl(142 71% 45%), hsl(180 70% 45%))" }}
            />
          </div>
        </div>

        {/* Overcharge Warning */}
        {financial.possible_overcharge > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-4 rounded-2xl p-5 flex items-start gap-4"
            style={{
              background: "rgba(220,60,60,0.07)",
              border: "1px solid rgba(220,60,60,0.25)",
              boxShadow: "0 0 30px rgba(220,60,60,0.07)",
            }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(220,60,60,0.15)" }}
            >
              <AlertTriangle className="w-5 h-5" style={{ color: "hsl(0 84% 60%)" }} />
            </div>
            <div>
              <p className="font-semibold text-white mb-1">Potential Overcharging Detected</p>
              <p className="text-sm text-white/50">
                This procedure may be billed {overchargePercent}% above standard scheme rates. The estimated overcharge
                is <span style={{ color: "hsl(0 84% 60%)" }}>{formatINR(financial.possible_overcharge)}</span>. Request
                an itemized bill and compare with PM-JAY package rates.
              </p>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* Section 4: Government Scheme Matching */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.3 }}>
        <div className="mb-4">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Shield className="w-5 h-5" style={{ color: "hsl(180 70% 45%)" }} />
            Government Scheme Matching
          </h3>
          <p className="text-white/40 text-sm mt-1">
            {schemes.length} schemes found for {result.simple_name}
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {schemes.map((scheme, i) => {
            const isRecommended = scheme.name === result.best_scheme;
            const color = SCHEME_COLORS[scheme.color] ?? "hsl(180 70% 45%)";
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + i * 0.07 }}
                className="rounded-2xl p-5 relative overflow-hidden"
                style={{
                  background: isRecommended ? "rgba(56,211,183,0.07)" : "rgba(14,20,38,0.8)",
                  border: `1px solid ${isRecommended ? "rgba(56,211,183,0.35)" : "rgba(255,255,255,0.07)"}`,
                  boxShadow: isRecommended ? "0 0 25px rgba(56,211,183,0.08)" : "none",
                }}
              >
                {isRecommended && (
                  <div
                    className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-xs font-bold"
                    style={{ background: "rgba(56,211,183,0.2)", color: "hsl(180 70% 45%)" }}
                  >
                    RECOMMENDED
                  </div>
                )}
                <h4 className="font-semibold text-white text-sm mb-3 pr-24">{scheme.name}</h4>
                <div className="flex items-end justify-between mb-3">
                  <div>
                    <p className="text-xs text-white/30 mb-0.5">Coverage Amount</p>
                    <p className="text-xl font-bold" style={{ color }}>
                      {formatINR(scheme.coverage_amount)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-white/30 mb-0.5">Coverage</p>
                    <p className="text-xl font-bold text-white">{scheme.coverage_percentage}%</p>
                  </div>
                </div>
                <div className="relative h-1.5 bg-white/10 rounded-full overflow-hidden mb-3">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${scheme.coverage_percentage}%` }}
                    transition={{ duration: 1, delay: 0.5 + i * 0.1 }}
                    className="absolute left-0 top-0 h-full rounded-full"
                    style={{ background: color }}
                  />
                </div>
                <p className="text-xs text-white/40 mb-2">{scheme.eligibility}</p>
                <p className="text-xs" style={{ color: "hsl(142 71% 45%)" }}>
                  {scheme.recommendation}
                </p>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Section 6: Hospital Trust Score */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.4 }}>
        {card(
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="relative w-40 h-40 flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart
                  cx="50%"
                  cy="50%"
                  innerRadius="60%"
                  outerRadius="80%"
                  startAngle={180}
                  endAngle={-180}
                  data={trustData}
                >
                  <RadialBar background={{ fill: "rgba(255,255,255,0.05)" }} dataKey="value" />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="text-3xl font-bold text-white">{trust_score}%</p>
                <p className="text-xs text-white/40">Trust Score</p>
              </div>
            </div>
            <div className="flex-1 space-y-4">
              <div>
                <p className="text-xs uppercase tracking-wider text-white/30 mb-2 flex items-center gap-2">
                  <Hospital className="w-3.5 h-3.5" /> Hospital Trust Analysis
                </p>
                <div
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-3"
                  style={{ background: riskConfig.bg, border: `1px solid ${riskConfig.color}40` }}
                >
                  <div className="w-2 h-2 rounded-full" style={{ background: riskConfig.color }} />
                  <span className="text-xs font-bold" style={{ color: riskConfig.color }}>
                    {riskConfig.label}
                  </span>
                </div>
                <p className="text-sm text-white/70">
                  {trust_score < 70
                    ? "This hospital may be charging above standard government scheme averages. Consider verifying with a second opinion or government hospital."
                    : trust_score < 80
                    ? "Trust score is moderate. Request itemized billing and verify scheme coverage before proceeding."
                    : "This hospital has a good trust score. Still request an itemized bill for transparency."}
                </p>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "LOW RISK", threshold: 80, active: risk_level === "Low" },
                  { label: "MEDIUM RISK", threshold: 65, active: risk_level === "Medium" },
                  { label: "HIGH RISK", threshold: 0, active: risk_level === "High" },
                ].map((r) => (
                  <div
                    key={r.label}
                    className="rounded-xl p-3 text-center"
                    style={{
                      background: r.active ? (r.label.includes("LOW") ? "rgba(56,200,90,0.1)" : r.label.includes("HIGH") ? "rgba(220,60,60,0.1)" : "rgba(234,179,8,0.1)") : "rgba(255,255,255,0.03)",
                      border: `1px solid ${r.active ? (r.label.includes("LOW") ? "rgba(56,200,90,0.3)" : r.label.includes("HIGH") ? "rgba(220,60,60,0.3)" : "rgba(234,179,8,0.3)") : "rgba(255,255,255,0.06)"}`,
                    }}
                  >
                    <p
                      className="text-xs font-bold"
                      style={{
                        color: r.active
                          ? r.label.includes("LOW")
                            ? "hsl(142 71% 45%)"
                            : r.label.includes("HIGH")
                            ? "hsl(0 84% 60%)"
                            : "hsl(45 90% 55%)"
                          : "rgba(255,255,255,0.2)",
                      }}
                    >
                      {r.label}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </motion.div>

      {/* Section 7: Smart Next Steps */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.5 }}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Questions to Ask */}
          {card(
            <div>
              <p className="text-xs uppercase tracking-wider text-white/30 mb-4 flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5" /> Questions to Ask Your Doctor
              </p>
              <div className="space-y-2">
                {result.questions_to_ask.map((q, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + i * 0.05 }}
                    className="flex items-start gap-3 p-3 rounded-xl"
                    style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" }}
                  >
                    <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(180 70% 45%)" }} />
                    <p className="text-sm text-white/70">{q}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Next Steps */}
          {card(
            <div>
              <p className="text-xs uppercase tracking-wider text-white/30 mb-4 flex items-center gap-2">
                <ChevronRight className="w-3.5 h-3.5" /> Recommended Next Steps
              </p>
              <div className="space-y-2">
                {result.next_steps.map((step, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + i * 0.05 }}
                    className="flex items-start gap-3 p-3 rounded-xl"
                    style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" }}
                  >
                    <span
                      className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5"
                      style={{ background: "rgba(56,211,183,0.15)", color: "hsl(180 70% 45%)" }}
                    >
                      {i + 1}
                    </span>
                    <p className="text-sm text-white/70">{step}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Nearby Hospitals */}
        <div className="mt-6">
          <p className="text-xs uppercase tracking-wider text-white/30 mb-4 flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5" /> Affordable Hospitals Nearby
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {result.nearby_hospitals.slice(0, 6).map((hospital, i) => {
              const riskCfg = RISK_CONFIG[hospital.risk_level] ?? RISK_CONFIG.Medium;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + i * 0.06 }}
                  className="rounded-2xl p-5"
                  style={{ background: "rgba(14,20,38,0.8)", border: "1px solid rgba(255,255,255,0.07)" }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ background: "rgba(56,211,183,0.1)" }}
                      >
                        <Hospital className="w-4 h-4" style={{ color: "hsl(180 70% 45%)" }} />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white leading-tight">{hospital.name}</p>
                        <p className="text-xs text-white/30 flex items-center gap-1">
                          <MapPin className="w-2.5 h-2.5" /> {hospital.distance}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold" style={{ color: riskCfg.color }}>
                        {hospital.trust_score}%
                      </p>
                      <p className="text-xs text-white/30">Trust</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mb-3">
                    <span
                      className="text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{ background: riskCfg.bg, color: riskCfg.color }}
                    >
                      {riskCfg.label}
                    </span>
                    <span
                      className="text-xs px-2 py-0.5 rounded-full"
                      style={{ background: "rgba(56,211,183,0.08)", color: "hsl(180 70% 45%)" }}
                    >
                      {hospital.affordability}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {hospital.scheme_support.map((s, j) => (
                      <span
                        key={j}
                        className="text-xs px-2 py-0.5 rounded-full"
                        style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.4)" }}
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* Section 8: Multilingual Support */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.6 }}>
        {card(
          <div>
            <p className="text-xs uppercase tracking-wider text-white/30 mb-4">Language & Voice Support</p>
            <div className="flex flex-wrap gap-3 mb-6">
              {[
                { key: "en", label: "English" },
                { key: "kn", label: "ಕನ್ನಡ" },
                { key: "hi", label: "हिंदी" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setLanguage(key as "en" | "kn" | "hi")}
                  className="px-5 py-2.5 rounded-xl font-medium text-sm transition-all"
                  style={{
                    background: language === key ? "rgba(56,211,183,0.15)" : "rgba(255,255,255,0.05)",
                    border: `1px solid ${language === key ? "rgba(56,211,183,0.4)" : "rgba(255,255,255,0.08)"}`,
                    color: language === key ? "hsl(180 70% 45%)" : "rgba(255,255,255,0.5)",
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
              <p className="text-sm text-white/60 md:col-span-2">
                {language === "en" && `Gallbladder surgery is covered under government healthcare schemes. You may be eligible for up to ${formatINR(financial.government_coverage)} in coverage. Always request an itemized bill.`}
                {language === "kn" && `ಪಿತ್ತಕೋಶ ಶಸ್ತ್ರಚಿಕಿತ್ಸೆ ಸರ್ಕಾರಿ ಆರೋಗ್ಯ ಯೋಜನೆಗಳ ಅಡಿ ಒಳಪಡುತ್ತದೆ. ನೀವು ${formatINR(financial.government_coverage)} ವರೆಗೆ ಹಣಕಾಸಿನ ಸಹಾಯ ಪಡೆಯಬಹುದು.`}
                {language === "hi" && `पित्ताशय की सर्जरी सरकारी स्वास्थ्य योजनाओं के अंतर्गत कवर होती है। आप ${formatINR(financial.government_coverage)} तक की सहायता के लिए पात्र हो सकते हैं।`}
              </p>
            </div>
            <div className="flex gap-3">
              {[
                { label: "Play Kannada Audio", lang: "kn" },
                { label: "Play Hindi Audio", lang: "hi" },
              ].map(({ label, lang }) => (
                <button
                  key={lang}
                  onClick={() => setLanguage(lang as "kn" | "hi")}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all"
                  style={{
                    background: "rgba(56,211,183,0.07)",
                    border: "1px solid rgba(56,211,183,0.2)",
                    color: "hsl(180 70% 45%)",
                  }}
                >
                  <Volume2 className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}
      </motion.div>

      {/* Section 10: Future Scope */}
      <motion.div variants={SECTION_VARIANTS} initial="hidden" animate="visible" transition={{ delay: 0.7 }}>
        <div className="mb-4">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Rocket className="w-5 h-5" style={{ color: "hsl(180 70% 45%)" }} />
            Future Scope
          </h3>
          <p className="text-white/40 text-sm mt-1">The healthcare ecosystem we are building</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {FUTURE_FEATURES.map(({ icon: Icon, label, desc }, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 + i * 0.07 }}
              className="rounded-2xl p-5"
              style={{
                background: "rgba(14,20,38,0.6)",
                border: "1px solid rgba(56,211,183,0.1)",
              }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                style={{ background: "rgba(56,211,183,0.1)" }}
              >
                <Icon className="w-5 h-5" style={{ color: "hsl(180 70% 45%)" }} />
              </div>
              <p className="font-semibold text-white text-sm mb-1">{label}</p>
              <p className="text-xs text-white/40">{desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
