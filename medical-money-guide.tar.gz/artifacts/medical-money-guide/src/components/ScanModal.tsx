import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Upload, Scan, FileText, Zap, Mic, MicOff } from "lucide-react";

interface ScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanComplete: (text: string) => void;
  onStartVoiceInput?: () => void;
  onStopVoiceInput?: () => void;
  isListening?: boolean;
  voiceTranscript?: string;
}

const MOCK_PRESCRIPTIONS = [
  "Patient advised Lap Chole surgery due to symptomatic cholelithiasis",
  "Appendectomy suggested — acute appendicitis confirmed on CT scan",
  "Kidney stone surgery (PCNL) recommended for 18mm renal calculus",
  "Cataract operation advised — phacoemulsification with IOL implant",
  "Laparoscopic hernia repair (herniorrhaphy) recommended",
];

const SCAN_STEPS = [
  "Initializing OCR engine...",
  "Extracting medical terminology...",
  "Cross-referencing drug database...",
  "Identifying procedures & treatments...",
  "Matching government scheme eligibility...",
  "Calculating financial impact...",
  "Analysis complete.",
];

export function ScanModal({
  isOpen,
  onClose,
  onScanComplete,
  onStartVoiceInput,
  onStopVoiceInput,
  isListening = false,
  voiceTranscript = "",
}: ScanModalProps) {
  const [phase, setPhase] = useState<"select" | "scanning" | "done">("select");
  const [selectedText, setSelectedText] = useState("");
  const [scanStep, setScanStep] = useState(0);
  const [typedText, setTypedText] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scanLineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) {
      setPhase("select");
      setSelectedText("");
      setScanStep(0);
      setTypedText("");
      setUploadedFileName(null);
    }
  }, [isOpen]);

  // Auto-scan when voice transcript arrives and is final
  useEffect(() => {
    if (
      voiceTranscript &&
      voiceTranscript.length > 10 &&
      phase === "select" &&
      !isListening
    ) {
      startScan(voiceTranscript);
    }
  }, [voiceTranscript, isListening]);

  useEffect(() => {
    if (phase !== "scanning") return;

    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < SCAN_STEPS.length) {
        setScanStep(stepIndex);
        typeStep(SCAN_STEPS[stepIndex]);
        stepIndex++;
      } else {
        clearInterval(interval);
        setPhase("done");
        setTimeout(() => {
          onScanComplete(selectedText);
        }, 600);
      }
    }, 600);

    return () => clearInterval(interval);
  }, [phase]);

  function typeStep(text: string) {
    let i = 0;
    setTypedText("");
    const t = setInterval(() => {
      setTypedText(text.slice(0, i + 1));
      i++;
      if (i >= text.length) clearInterval(t);
    }, 30);
  }

  function startScan(text: string) {
    setSelectedText(text);
    setPhase("scanning");
    setScanStep(0);
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFileName(file.name);
      setTimeout(() => {
        startScan(
          `Patient prescribed ${file.name.replace(/\.[^.]+$/, "")} — prescription document uploaded for analysis`,
        );
      }, 800);
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{
            backgroundColor: "rgba(8, 12, 24, 0.92)",
            backdropFilter: "blur(20px)",
          }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="w-full max-w-2xl relative"
            style={{
              background: "rgba(14, 20, 38, 0.95)",
              border: "1px solid rgba(56, 211, 183, 0.2)",
              borderRadius: "1.5rem",
              boxShadow:
                "0 0 60px rgba(56, 211, 183, 0.1), 0 25px 60px rgba(0,0,0,0.5)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/5">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{
                    background: "rgba(56, 211, 183, 0.15)",
                    border: "1px solid rgba(56, 211, 183, 0.3)",
                  }}
                >
                  <Scan
                    className="w-5 h-5"
                    style={{ color: "hsl(180 70% 45%)" }}
                  />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">
                    AI Prescription Scanner
                  </h2>
                  <p className="text-xs text-white/40">
                    Powered by Medical Money Guide AI
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4 text-white/60" />
              </button>
            </div>

            <div className="p-6">
              <AnimatePresence mode="wait">
                {/* SELECT PHASE */}
                {phase === "select" && (
                  <motion.div
                    key="select"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    {/* Upload Zone */}
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="relative border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all group"
                      style={{
                        borderColor: uploadedFileName
                          ? "rgba(56, 211, 183, 0.6)"
                          : "rgba(56, 211, 183, 0.25)",
                        background: "rgba(56, 211, 183, 0.03)",
                      }}
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={handleFileUpload}
                      />
                      <div
                        className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-transform group-hover:scale-110"
                        style={{ background: "rgba(56, 211, 183, 0.1)" }}
                      >
                        {uploadedFileName ? (
                          <FileText
                            className="w-8 h-8"
                            style={{ color: "hsl(180 70% 45%)" }}
                          />
                        ) : (
                          <Upload
                            className="w-8 h-8"
                            style={{ color: "hsl(180 70% 45%)" }}
                          />
                        )}
                      </div>
                      {uploadedFileName ? (
                        <p
                          className="text-sm font-medium"
                          style={{ color: "hsl(180 70% 45%)" }}
                        >
                          {uploadedFileName} — scanning...
                        </p>
                      ) : (
                        <>
                          <p className="text-white font-medium mb-1">
                            Upload Prescription Image
                          </p>
                          <p className="text-white/40 text-sm">
                            JPG, PNG, or PDF — drag and drop or click to browse
                          </p>
                        </>
                      )}
                    </div>

                    {/* Voice Input Button */}
                    {(onStartVoiceInput || onStopVoiceInput) && (
                      <motion.button
                        onClick={
                          isListening ? onStopVoiceInput : onStartVoiceInput
                        }
                        whileTap={{ scale: 0.97 }}
                        className="w-full flex items-center justify-center gap-3 py-4 rounded-xl transition-all"
                        style={{
                          background: isListening
                            ? "rgba(220, 60, 60, 0.1)"
                            : "rgba(56, 211, 183, 0.06)",
                          border: `2px solid ${isListening ? "rgba(220,60,60,0.4)" : "rgba(56,211,183,0.25)"}`,
                        }}
                      >
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center"
                          style={{
                            background: isListening
                              ? "rgba(220,60,60,0.2)"
                              : "rgba(56,211,183,0.15)",
                          }}
                        >
                          {isListening ? (
                            <motion.div
                              animate={{ scale: [1, 1.25, 1] }}
                              transition={{ repeat: Infinity, duration: 0.9 }}
                            >
                              <MicOff className="w-5 h-5 text-red-400" />
                            </motion.div>
                          ) : (
                            <Mic
                              className="w-5 h-5"
                              style={{ color: "hsl(180 70% 45%)" }}
                            />
                          )}
                        </div>
                        <div className="text-left">
                          <p
                            className="text-sm font-semibold"
                            style={{
                              color: isListening
                                ? "hsl(0 84% 65%)"
                                : "hsl(180 70% 45%)",
                            }}
                          >
                            {isListening
                              ? "Listening... tap to stop"
                              : "Speak Your Prescription"}
                          </p>
                          <p className="text-xs text-white/30">
                            {isListening
                              ? voiceTranscript ||
                                "Say your prescription text clearly..."
                              : "Say the prescription text aloud"}
                          </p>
                        </div>
                        {isListening && (
                          <div className="ml-auto flex gap-0.5 items-center">
                            {[0, 0.1, 0.2, 0.1, 0].map((d, i) => (
                              <motion.div
                                key={i}
                                animate={{ scaleY: [1, 2.5, 1] }}
                                transition={{
                                  repeat: Infinity,
                                  duration: 0.7,
                                  delay: d,
                                }}
                                style={{
                                  width: 3,
                                  height: 14,
                                  borderRadius: 2,
                                  background: "hsl(0 84% 65%)",
                                  transformOrigin: "center",
                                }}
                              />
                            ))}
                          </div>
                        )}
                      </motion.button>
                    )}

                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-px bg-white/10" />
                      <span className="text-white/30 text-xs font-medium">
                        OR TRY A DEMO
                      </span>
                      <div className="flex-1 h-px bg-white/10" />
                    </div>

                    {/* Mock Prescriptions */}
                    <div className="space-y-2">
                      <p className="text-xs text-white/40 uppercase tracking-wider mb-3">
                        Sample Prescriptions
                      </p>
                      {MOCK_PRESCRIPTIONS.map((text, i) => (
                        <motion.button
                          key={i}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.05 }}
                          onClick={() => startScan(text)}
                          className="w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 group transition-all"
                          style={{
                            background: "rgba(255,255,255,0.03)",
                            border: "1px solid rgba(255,255,255,0.06)",
                          }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLElement).style.background =
                              "rgba(56, 211, 183, 0.07)";
                            (e.currentTarget as HTMLElement).style.borderColor =
                              "rgba(56, 211, 183, 0.25)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLElement).style.background =
                              "rgba(255,255,255,0.03)";
                            (e.currentTarget as HTMLElement).style.borderColor =
                              "rgba(255,255,255,0.06)";
                          }}
                        >
                          <div
                            className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                            style={{ background: "rgba(56, 211, 183, 0.1)" }}
                          >
                            <FileText
                              className="w-3.5 h-3.5"
                              style={{ color: "hsl(180 70% 45%)" }}
                            />
                          </div>
                          <span className="text-sm text-white/70 group-hover:text-white transition-colors line-clamp-2">
                            {text}
                          </span>
                          <Zap
                            className="w-3.5 h-3.5 ml-auto flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                            style={{ color: "hsl(180 70% 45%)" }}
                          />
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* SCANNING PHASE */}
                {(phase === "scanning" || phase === "done") && (
                  <motion.div
                    key="scanning"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-6"
                  >
                    {/* Scan Animation Area */}
                    <div
                      className="relative rounded-xl overflow-hidden"
                      style={{
                        height: "180px",
                        background: "rgba(56, 211, 183, 0.04)",
                        border: "1px solid rgba(56, 211, 183, 0.15)",
                      }}
                    >
                      {/* Grid lines */}
                      <div
                        className="absolute inset-0 opacity-20"
                        style={{
                          backgroundImage:
                            "linear-gradient(rgba(56, 211, 183, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(56, 211, 183, 0.3) 1px, transparent 1px)",
                          backgroundSize: "30px 30px",
                        }}
                      />

                      {/* Scan line */}
                      <div
                        className="scan-line"
                        style={{
                          background:
                            "linear-gradient(90deg, transparent, rgba(56,211,183,0.8), rgba(56,211,183,1), rgba(56,211,183,0.8), transparent)",
                          boxShadow:
                            "0 0 20px rgba(56,211,183,0.8), 0 0 40px rgba(56,211,183,0.4)",
                        }}
                      />

                      {/* Center Orb */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="relative">
                          <motion.div
                            animate={{
                              scale: [1, 1.3, 1],
                              opacity: [0.5, 1, 0.5],
                            }}
                            transition={{ repeat: Infinity, duration: 2 }}
                            className="w-16 h-16 rounded-full"
                            style={{
                              background:
                                "radial-gradient(circle, rgba(56,211,183,0.4) 0%, rgba(56,211,183,0) 70%)",
                              border: "2px solid rgba(56,211,183,0.5)",
                            }}
                          />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Scan
                              className="w-6 h-6"
                              style={{ color: "hsl(180 70% 45%)" }}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Corner brackets */}
                      {[
                        "top-2 left-2",
                        "top-2 right-2",
                        "bottom-2 left-2",
                        "bottom-2 right-2",
                      ].map((pos, i) => (
                        <div
                          key={i}
                          className={`absolute ${pos} w-5 h-5`}
                          style={{
                            borderTop:
                              i < 2 ? "2px solid rgba(56,211,183,0.6)" : "none",
                            borderBottom:
                              i >= 2
                                ? "2px solid rgba(56,211,183,0.6)"
                                : "none",
                            borderLeft:
                              i % 2 === 0
                                ? "2px solid rgba(56,211,183,0.6)"
                                : "none",
                            borderRight:
                              i % 2 === 1
                                ? "2px solid rgba(56,211,183,0.6)"
                                : "none",
                          }}
                        />
                      ))}
                    </div>

                    {/* Scan Steps */}
                    <div
                      className="rounded-xl p-4 font-mono text-sm space-y-1"
                      style={{
                        background: "rgba(0,0,0,0.4)",
                        border: "1px solid rgba(255,255,255,0.05)",
                      }}
                    >
                      {SCAN_STEPS.slice(0, scanStep).map((step, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <span style={{ color: "hsl(142 71% 45%)" }}>✓</span>
                          <span className="text-white/40 text-xs">{step}</span>
                        </div>
                      ))}
                      {phase === "scanning" && (
                        <div className="flex items-center gap-2">
                          <motion.span
                            animate={{ opacity: [0, 1, 0] }}
                            transition={{ repeat: Infinity, duration: 0.8 }}
                            style={{ color: "hsl(180 70% 45%)" }}
                          >
                            &gt;
                          </motion.span>
                          <span className="text-white/80 text-xs">
                            {typedText}
                          </span>
                          <motion.span
                            animate={{ opacity: [1, 0] }}
                            transition={{ repeat: Infinity, duration: 0.5 }}
                            className="text-white"
                          >
                            _
                          </motion.span>
                        </div>
                      )}
                      {phase === "done" && (
                        <div className="flex items-center gap-2 mt-2">
                          <span style={{ color: "hsl(180 70% 45%)" }}>✓</span>
                          <span
                            className="font-bold text-xs"
                            style={{ color: "hsl(180 70% 45%)" }}
                          >
                            Analysis complete — loading results...
                          </span>
                        </div>
                      )}
                    </div>

                    <div
                      className="rounded-lg p-3"
                      style={{
                        background: "rgba(56,211,183,0.05)",
                        border: "1px solid rgba(56,211,183,0.1)",
                      }}
                    >
                      <p className="text-xs text-white/40 mb-1">
                        Prescription text detected:
                      </p>
                      <p className="text-xs text-white/70 italic line-clamp-2">
                        {selectedText}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
