import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, MicOff, Volume2, VolumeX, Globe, X, Activity } from "lucide-react";
import type { VoiceLang } from "@/hooks/useVoice";

interface VoiceAssistantProps {
  isSpeaking: boolean;
  isListening: boolean;
  isSupported: boolean;
  isSttSupported: boolean;
  currentLang: VoiceLang;
  hasResult: boolean;
  onSpeak: () => void;
  onStop: () => void;
  onListen: () => void;
  onStopListening: () => void;
  onLangChange: (lang: VoiceLang) => void;
}

const LANGS: { key: VoiceLang; label: string; native: string }[] = [
  { key: "en", label: "English", native: "English" },
  { key: "hi", label: "Hindi", native: "हिंदी" },
  { key: "kn", label: "Kannada", native: "ಕನ್ನಡ" },
];

export function VoiceAssistant({
  isSpeaking,
  isListening,
  isSupported,
  isSttSupported,
  currentLang,
  hasResult,
  onSpeak,
  onStop,
  onListen,
  onStopListening,
  onLangChange,
}: VoiceAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);

  const teal = "hsl(180 70% 45%)";
  const tealBg = "rgba(56, 211, 183, 0.12)";
  const tealBorder = "rgba(56, 211, 183, 0.3)";

  const WaveBar = ({ delay }: { delay: number }) => (
    <motion.div
      animate={isSpeaking || isListening ? { scaleY: [1, 2.5, 1, 3, 1] } : { scaleY: 1 }}
      transition={{ repeat: Infinity, duration: 0.8, delay, ease: "easeInOut" }}
      style={{
        width: 3,
        height: 16,
        borderRadius: 2,
        background: isListening ? "hsl(0 84% 65%)" : teal,
        transformOrigin: "center",
      }}
    />
  );

  return (
    <>
      {/* Floating FAB */}
      <motion.button
        onClick={() => setIsOpen((o) => !o)}
        whileTap={{ scale: 0.93 }}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl"
        style={{
          background: isListening
            ? "rgba(220, 60, 60, 0.9)"
            : isSpeaking
            ? "rgba(56, 211, 183, 0.9)"
            : "rgba(14, 20, 38, 0.95)",
          border: `2px solid ${isListening ? "rgba(220,60,60,0.6)" : tealBorder}`,
          boxShadow: isListening
            ? "0 0 30px rgba(220,60,60,0.5)"
            : isSpeaking
            ? `0 0 30px rgba(56,211,183,0.5)`
            : `0 0 20px rgba(56,211,183,0.2)`,
        }}
      >
        <AnimatePresence mode="wait">
          {isSpeaking ? (
            <motion.div key="speaking" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="flex gap-0.5 items-center">
              {[0, 0.15, 0.3, 0.15, 0].map((d, i) => <WaveBar key={i} delay={d} />)}
            </motion.div>
          ) : isListening ? (
            <motion.div key="listening" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
              <motion.div
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ repeat: Infinity, duration: 1 }}
              >
                <Mic className="w-6 h-6 text-white" />
              </motion.div>
            </motion.div>
          ) : (
            <motion.div key="idle" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
              <Activity className="w-6 h-6" style={{ color: teal }} />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Voice Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", damping: 22, stiffness: 300 }}
            className="fixed bottom-24 right-6 z-50 w-72 rounded-2xl overflow-hidden"
            style={{
              background: "rgba(10, 14, 28, 0.97)",
              border: `1px solid ${tealBorder}`,
              boxShadow: "0 20px 60px rgba(0,0,0,0.6), 0 0 40px rgba(56,211,183,0.08)",
              backdropFilter: "blur(20px)",
            }}
          >
            {/* Panel Header */}
            <div
              className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
            >
              <div className="flex items-center gap-2">
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: tealBg, border: `1px solid ${tealBorder}` }}
                >
                  <Activity className="w-3.5 h-3.5" style={{ color: teal }} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Voice Assistant</p>
                  <p className="text-xs" style={{ color: teal }}>
                    {isSpeaking ? "Speaking..." : isListening ? "Listening..." : "Ready"}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-6 h-6 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.07)" }}
              >
                <X className="w-3 h-3 text-white/60" />
              </button>
            </div>

            {/* Waveform Visualizer */}
            <div
              className="mx-4 my-3 rounded-xl flex items-center justify-center gap-1"
              style={{
                height: 52,
                background: isSpeaking || isListening ? "rgba(56,211,183,0.05)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${isSpeaking || isListening ? "rgba(56,211,183,0.2)" : "rgba(255,255,255,0.06)"}`,
                transition: "all 0.3s",
              }}
            >
              {isSpeaking || isListening ? (
                [0, 0.1, 0.2, 0.1, 0.3, 0.15, 0.25, 0.05, 0.2, 0.1].map((d, i) => (
                  <WaveBar key={i} delay={d} />
                ))
              ) : (
                <div className="flex items-center gap-1.5">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      style={{ width: 3, height: i % 3 === 1 ? 12 : i % 3 === 2 ? 6 : 8, borderRadius: 2, background: "rgba(255,255,255,0.12)" }}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Status Message */}
            {(isSpeaking || isListening) && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center text-xs px-4 mb-2"
                style={{ color: isListening ? "hsl(0 84% 65%)" : teal }}
              >
                {isListening ? "Say your prescription text clearly..." : "Reading your analysis results..."}
              </motion.p>
            )}

            {/* Language Selector */}
            <div className="px-4 mb-3">
              <p className="text-xs text-white/30 mb-2 flex items-center gap-1.5">
                <Globe className="w-3 h-3" /> Language
              </p>
              <div className="grid grid-cols-3 gap-1.5">
                {LANGS.map(({ key, native }) => (
                  <button
                    key={key}
                    onClick={() => onLangChange(key)}
                    className="py-1.5 rounded-lg text-xs font-medium transition-all"
                    style={{
                      background: currentLang === key ? tealBg : "rgba(255,255,255,0.04)",
                      border: `1px solid ${currentLang === key ? tealBorder : "rgba(255,255,255,0.07)"}`,
                      color: currentLang === key ? teal : "rgba(255,255,255,0.4)",
                    }}
                  >
                    {native}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="px-4 pb-4 space-y-2">
              {/* Read Results Button */}
              {isSupported && (
                <button
                  onClick={isSpeaking ? onStop : onSpeak}
                  disabled={!hasResult}
                  className="w-full py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  style={{
                    background: isSpeaking ? "rgba(220,60,60,0.15)" : tealBg,
                    border: `1px solid ${isSpeaking ? "rgba(220,60,60,0.4)" : tealBorder}`,
                    color: isSpeaking ? "hsl(0 84% 65%)" : teal,
                  }}
                >
                  {isSpeaking ? (
                    <><VolumeX className="w-4 h-4" /> Stop Speaking</>
                  ) : (
                    <><Volume2 className="w-4 h-4" /> Read My Results</>
                  )}
                </button>
              )}

              {/* Voice Input Button */}
              {isSttSupported && (
                <button
                  onClick={isListening ? onStopListening : onListen}
                  className="w-full py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
                  style={{
                    background: isListening ? "rgba(220,60,60,0.15)" : "rgba(255,255,255,0.04)",
                    border: `1px solid ${isListening ? "rgba(220,60,60,0.4)" : "rgba(255,255,255,0.1)"}`,
                    color: isListening ? "hsl(0 84% 65%)" : "rgba(255,255,255,0.6)",
                  }}
                >
                  {isListening ? (
                    <><MicOff className="w-4 h-4" /> Stop Listening</>
                  ) : (
                    <><Mic className="w-4 h-4" /> Speak Prescription</>
                  )}
                </button>
              )}

              {!isSupported && !isSttSupported && (
                <p className="text-xs text-center text-white/30 py-2">
                  Voice not supported in this browser. Try Chrome or Edge.
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
