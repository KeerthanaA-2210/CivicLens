# Medical Money Guide

A cinematic healthcare-financial AI web app for Indian families — scans prescriptions, identifies medical procedures in plain language, matches government schemes (PM-JAY, Green Card, ESI, BPL, Karnataka), analyzes financial protection, and detects hospital overcharging.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port assigned by workflow)
- `pnpm --filter @workspace/medical-money-guide run dev` — run the React frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Tailwind CSS, framer-motion, GSAP, recharts
- API: Express 5 (artifacts/api-server)
- DB: None — medical schemes data is embedded in route code
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `artifacts/medical-money-guide/src/pages/Home.tsx` — main SPA page with hero, scan modal trigger, results rendering
- `artifacts/medical-money-guide/src/components/ScanModal.tsx` — prescription scan modal with laser animation
- `artifacts/medical-money-guide/src/components/FinancialDashboard.tsx` — all results sections (financial, schemes, hospitals, next steps)
- `artifacts/api-server/src/routes/medical.ts` — /analyze, /schemes, /hospitals, /stats endpoints with embedded scheme data
- `artifacts/medical-money-guide/src/index.css` — dark navy theme, glassmorphism, glow effects, particle animations

## Architecture decisions

- Schemes data is embedded directly in `medical.ts` (not a JSON file) to avoid path resolution issues when the server bundle runs from `dist/`
- Single-page app — all sections are conditionally rendered after prescription analysis, no routes beyond "/"
- GSAP for hero entrance, framer-motion for modal and results transitions
- All HSL CSS variables set in `:root, .dark` — always dark mode, forced via `document.documentElement.classList.add('dark')`

## Product

- Hero with cinematic headline and floating particle background
- "Scan Prescription" button opens futuristic modal with laser scanning animation
- Selectable mock prescriptions (5 types) or image upload simulation
- AI Medical Mapper: translates medical jargon to plain language with confidence score
- Government Scheme Matching: PM-JAY, Green Card, ESI, BPL, Karnataka Arogya Karnataka
- Financial Analysis: hospital cost, government coverage, patient expense, overcharge detection
- Hospital Trust Score with animated radial gauge
- Smart Next Steps: questions to ask doctor + recommended next steps
- Nearby hospital cards with trust scores and scheme support
- Multilingual support UI: English / ಕನ್ನಡ / हिंदी (simulation)
- Social impact stats from live API
- Future scope roadmap cards

## User preferences

- Dark cinematic healthcare-fintech aesthetic
- Teal glowing accents on dark navy background
- Glassmorphism cards with backdrop blur
- Premium hackathon-ready demo experience

## Gotchas

- Do not read JSON from file in api-server routes — embed data in TS to avoid dist/ path issues
- Google Fonts @import MUST be the first line of index.css (before @import "tailwindcss")
- Always run `pnpm --filter @workspace/api-spec run codegen` after changing openapi.yaml
- framer-motion `ease` in Variants must be `Easing` type — use `as const` on variant definitions
